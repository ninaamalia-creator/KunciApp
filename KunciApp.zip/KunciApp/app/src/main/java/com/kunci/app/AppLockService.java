package com.kunci.app;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

import java.util.Set;

/**
 * Mendeteksi aplikasi yang dibuka. Kalau aplikasi itu ada di daftar kunci,
 * tampilkan layar PIN (LockActivity).
 */
public class AppLockService extends AccessibilityService {

    /** Aplikasi yang baru saja dibuka dengan PIN benar (terkunci lagi saat ditinggal / layar mati). */
    static volatile String unlockedPkg = null;

    private BroadcastReceiver screenOffReceiver;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        screenOffReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                unlockedPkg = null;
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenOffReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(screenOffReceiver, filter);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence pkgCs = event.getPackageName();
        if (pkgCs == null) return;
        String pkg = pkgCs.toString();
        CharSequence cls = event.getClassName();

        if (pkg.equals(getPackageName())) {
            // Membuka layar pengaturan KunciApp sendiri = meninggalkan aplikasi yang tadi dibuka.
            if (cls != null && !LockActivity.class.getName().equals(cls.toString())) {
                unlockedPkg = null;
            }
            return;
        }

        Set<String> locked = Prefs.getLocked(this);
        if (locked.contains(pkg)) {
            if (!pkg.equals(unlockedPkg)) showLock(pkg);
        } else if (isActivity(pkg, cls)) {
            // Pindah ke aplikasi lain (mis. layar utama) -> kunci lagi.
            unlockedPkg = null;
        }
    }

    private boolean isActivity(String pkg, CharSequence cls) {
        if (cls == null) return false;
        try {
            getPackageManager().getActivityInfo(new ComponentName(pkg, cls.toString()), 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false; // jendela kecil seperti keyboard, notifikasi, dialog sistem
        }
    }

    private void showLock(String pkg) {
        Intent i = new Intent(this, LockActivity.class);
        i.putExtra(LockActivity.EXTRA_PKG, pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        if (screenOffReceiver != null) {
            try {
                unregisterReceiver(screenOffReceiver);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }
}
