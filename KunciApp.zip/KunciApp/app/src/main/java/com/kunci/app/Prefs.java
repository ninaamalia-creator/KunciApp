package com.kunci.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

/** Penyimpanan PIN (di-hash) dan daftar aplikasi yang dikunci. */
final class Prefs {
    static final int OK = 0;
    static final int WRONG = 1;
    static final int LOCKED_OUT = 2;

    private static final int MAX_FAILS = 5;
    private static final long LOCKOUT_MS = 30_000L;

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("kunci", Context.MODE_PRIVATE);
    }

    static boolean hasPin(Context c) {
        return sp(c).contains("pin_hash");
    }

    static int pinLength(Context c) {
        return sp(c).getInt("pin_len", 0);
    }

    static void setPin(Context c, String pin) {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        String salt = toHex(saltBytes);
        sp(c).edit()
                .putString("pin_salt", salt)
                .putString("pin_hash", hash(salt, pin))
                .putInt("pin_len", pin.length())
                .putInt("fails", 0)
                .putLong("lockout_until", 0L)
                .apply();
    }

    /** Cek PIN; setelah 5x salah, dikunci 30 detik. */
    static int verify(Context c, String pin) {
        long now = System.currentTimeMillis();
        SharedPreferences p = sp(c);
        if (now < p.getLong("lockout_until", 0L)) return LOCKED_OUT;

        String salt = p.getString("pin_salt", "");
        String stored = p.getString("pin_hash", null);
        boolean match = stored != null && MessageDigest.isEqual(
                stored.getBytes(StandardCharsets.UTF_8),
                hash(salt, pin).getBytes(StandardCharsets.UTF_8));
        if (match) {
            p.edit().putInt("fails", 0).apply();
            return OK;
        }
        int fails = p.getInt("fails", 0) + 1;
        if (fails >= MAX_FAILS) {
            p.edit().putInt("fails", 0).putLong("lockout_until", now + LOCKOUT_MS).apply();
            return LOCKED_OUT;
        }
        p.edit().putInt("fails", fails).apply();
        return WRONG;
    }

    static long lockoutSecondsLeft(Context c) {
        long ms = sp(c).getLong("lockout_until", 0L) - System.currentTimeMillis();
        return ms > 0 ? (ms + 999) / 1000 : 0;
    }

    static Set<String> getLocked(Context c) {
        return new HashSet<>(sp(c).getStringSet("locked", new HashSet<String>()));
    }

    static void setLocked(Context c, Set<String> pkgs) {
        sp(c).edit().putStringSet("locked", new HashSet<>(pkgs)).apply();
    }

    private static String hash(String salt, String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return toHex(md.digest((salt + ":" + pin).getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String toHex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
