package com.kunci.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Layar pengaturan: buat PIN, pilih aplikasi yang dikunci, aktifkan layanan. */
public class MainActivity extends Activity {

    private boolean authed = false;
    private TextView statusText;
    private Button enableButton;

    private static class AppItem {
        String pkg;
        String label;
        Drawable icon;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Prefs.hasPin(this) && !authed) {
            showLogin();
        } else if (statusText != null) {
            updateStatus();
        }
    }

    /** Kunci lagi layar pengaturan kalau HP ditinggal (tombol Home / Recent). */
    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        authed = false;
    }

    private void render() {
        if (!Prefs.hasPin(this)) showSetup(false);
        else if (!authed) showLogin();
        else showMain();
    }

    // ---------- Buat / ganti PIN ----------
    private void showSetup(boolean changing) {
        statusText = null;
        LinearLayout root = column();
        root.addView(heading(changing ? "Ganti PIN" : "Selamat datang di KunciApp"));
        root.addView(body("Buat PIN 4–8 angka. PIN ini dipakai untuk membuka aplikasi yang dikunci dan pengaturan KunciApp. Jangan beri tahu anak."));

        EditText pin1 = pinField("PIN baru");
        EditText pin2 = pinField("Ulangi PIN");
        root.addView(pin1);
        root.addView(pin2);

        Button save = new Button(this);
        save.setText("Simpan PIN");
        save.setOnClickListener(v -> {
            String a = pin1.getText().toString();
            String b = pin2.getText().toString();
            if (a.length() < 4) {
                toast("PIN minimal 4 angka");
            } else if (!a.equals(b)) {
                toast("PIN tidak sama, ulangi");
                pin2.setText("");
            } else {
                Prefs.setPin(this, a);
                authed = true;
                toast("PIN disimpan");
                showMain();
            }
        });
        root.addView(save);

        if (changing) {
            Button cancel = new Button(this);
            cancel.setText("Batal");
            cancel.setOnClickListener(v -> showMain());
            root.addView(cancel);
        }
        setContentView(root);
    }

    // ---------- Masuk dengan PIN ----------
    private void showLogin() {
        statusText = null;
        LinearLayout root = column();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_kunci);
        root.addView(logo, new LinearLayout.LayoutParams(dp(72), dp(72)));
        root.addView(heading("Masukkan PIN"));
        TextView info = body("");
        root.addView(info);

        EditText pin = pinField("PIN");
        root.addView(pin);
        Runnable check = () -> {
            String p = pin.getText().toString();
            if (p.isEmpty()) return;
            int r = Prefs.verify(this, p);
            pin.setText("");
            if (r == Prefs.OK) {
                authed = true;
                showMain();
            } else if (r == Prefs.LOCKED_OUT) {
                info.setText("Terlalu banyak salah. Tunggu " + Prefs.lockoutSecondsLeft(this) + " detik.");
            } else {
                info.setText("PIN salah.");
            }
        };
        pin.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (s.length() == Prefs.pinLength(MainActivity.this)) pin.post(check);
            }
        });
        Button ok = new Button(this);
        ok.setText("Masuk");
        ok.setOnClickListener(v -> check.run());
        root.addView(ok);
        setContentView(root);
        pin.requestFocus();
    }

    // ---------- Layar utama ----------
    private void showMain() {
        LinearLayout root = column();

        statusText = body("");
        statusText.setTextSize(16);
        root.addView(statusText);

        enableButton = new Button(this);
        enableButton.setText("Aktifkan pengunci");
        enableButton.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });
        root.addView(enableButton);

        Button changePin = new Button(this);
        changePin.setText("Ganti PIN");
        changePin.setOnClickListener(v -> showSetup(true));
        root.addView(changePin);

        TextView tip = body("Centang aplikasi yang mau dikunci. Saran: kunci juga \"Setelan/Settings\" dan \"Play Store\" supaya anak tidak bisa mematikan pengunci atau memasang game lain.");
        tip.setPadding(0, dp(12), 0, dp(4));
        root.addView(tip);

        ListView list = new ListView(this);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        TextView loading = body("Memuat daftar aplikasi…");
        root.addView(loading);

        setContentView(root);
        updateStatus();

        final Context ctx = getApplicationContext();
        new Thread(() -> {
            List<AppItem> apps = loadApps(ctx);
            runOnUiThread(() -> {
                loading.setVisibility(View.GONE);
                list.setAdapter(new AppAdapter(apps));
            });
        }).start();
    }

    private void updateStatus() {
        if (statusText == null) return;
        if (isServiceEnabled()) {
            statusText.setText("✅ Pengunci AKTIF");
            statusText.setTextColor(Color.parseColor("#067647"));
            enableButton.setVisibility(View.GONE);
        } else {
            statusText.setText("⚠️ Pengunci BELUM aktif.\nTekan tombol di bawah → pilih \"KunciApp\" (kadang di menu \"Aplikasi terunduh / Installed apps\") → aktifkan.");
            statusText.setTextColor(Color.parseColor("#B42318"));
            enableButton.setVisibility(View.VISIBLE);
        }
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(this, AppLockService.class);
        return enabled.contains(me.flattenToString()) || enabled.contains(me.flattenToShortString());
    }

    private static List<AppItem> loadApps(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
        Set<String> seen = new HashSet<>();
        Set<String> locked = Prefs.getLocked(ctx);
        List<AppItem> out = new ArrayList<>();
        for (ResolveInfo ri : infos) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(ctx.getPackageName()) || !seen.add(pkg)) continue;
            AppItem it = new AppItem();
            it.pkg = pkg;
            it.label = String.valueOf(ri.loadLabel(pm));
            try {
                it.icon = ri.loadIcon(pm);
            } catch (Exception e) {
                it.icon = null;
            }
            out.add(it);
        }
        Collator col = Collator.getInstance();
        out.sort((a, b) -> {
            boolean la = locked.contains(a.pkg), lb = locked.contains(b.pkg);
            if (la != lb) return la ? -1 : 1; // yang terkunci di atas
            return col.compare(a.label, b.label);
        });
        return out;
    }

    private class AppAdapter extends BaseAdapter {
        private final List<AppItem> apps;
        private final Set<String> locked;

        AppAdapter(List<AppItem> apps) {
            this.apps = apps;
            this.locked = Prefs.getLocked(MainActivity.this);
        }

        @Override public int getCount() { return apps.size(); }
        @Override public Object getItem(int i) { return apps.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            ImageView iv;
            TextView tv;
            CheckBox cb;
            if (convert == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(4), dp(8), dp(4), dp(8));
                iv = new ImageView(MainActivity.this);
                row.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
                tv = new TextView(MainActivity.this);
                tv.setTextSize(16);
                tv.setTextColor(Color.parseColor("#101828"));
                tv.setPadding(dp(12), 0, dp(8), 0);
                row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                cb = new CheckBox(MainActivity.this);
                cb.setClickable(false);
                cb.setFocusable(false);
                row.addView(cb);
            } else {
                row = (LinearLayout) convert;
                iv = (ImageView) row.getChildAt(0);
                tv = (TextView) row.getChildAt(1);
                cb = (CheckBox) row.getChildAt(2);
            }
            AppItem it = apps.get(pos);
            iv.setImageDrawable(it.icon);
            tv.setText(it.label);
            cb.setChecked(locked.contains(it.pkg));
            row.setOnClickListener(v -> {
                if (locked.contains(it.pkg)) locked.remove(it.pkg);
                else locked.add(it.pkg);
                Prefs.setLocked(MainActivity.this, locked);
                cb.setChecked(locked.contains(it.pkg));
            });
            return row;
        }
    }

    // ---------- helper UI ----------
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setFitsSystemWindows(true);
        l.setPadding(dp(20), dp(16), dp(20), dp(8));
        return l;
    }

    private TextView heading(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(22);
        t.setTextColor(Color.parseColor("#101828"));
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, dp(12), 0, dp(8));
        return t;
    }

    private TextView body(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15);
        t.setTextColor(Color.parseColor("#475467"));
        t.setPadding(0, dp(4), 0, dp(8));
        return t;
    }

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        e.setGravity(Gravity.CENTER);
        e.setTextSize(22);
        return e;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
