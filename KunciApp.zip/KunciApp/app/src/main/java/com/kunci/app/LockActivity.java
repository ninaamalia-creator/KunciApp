package com.kunci.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Layar PIN yang muncul di atas aplikasi yang dikunci. */
public class LockActivity extends Activity {
    static final String EXTRA_PKG = "pkg";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private String targetPkg;
    private ImageView icon;
    private TextView title;
    private TextView message;
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#101828"));
        root.setFitsSystemWindows(true);
        root.setPadding(dp(24), dp(56), dp(24), dp(24));

        icon = new ImageView(this);
        root.addView(icon, new LinearLayout.LayoutParams(dp(72), dp(72)));

        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(16), 0, dp(4));
        root.addView(title, matchWrap());

        message = new TextView(this);
        message.setTextColor(Color.parseColor("#98A2B3"));
        message.setTextSize(15);
        message.setGravity(Gravity.CENTER);
        message.setText("Masukkan PIN untuk membuka");
        message.setPadding(0, 0, 0, dp(20));
        root.addView(message, matchWrap());

        input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        input.setGravity(Gravity.CENTER);
        input.setTextSize(28);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.parseColor("#667085"));
        input.setHint("PIN");
        root.addView(input, new LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.WRAP_CONTENT));

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                int len = Prefs.pinLength(LockActivity.this);
                if (len > 0 && s.length() == len) handler.post(LockActivity.this::tryUnlock);
            }
        });

        Button open = new Button(this);
        open.setText("Buka");
        open.setOnClickListener(v -> tryUnlock());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(16);
        root.addView(open, lp);

        Button back = new Button(this);
        back.setText("Kembali ke layar utama");
        back.setOnClickListener(v -> goHome());
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.topMargin = dp(8);
        root.addView(back, lp2);

        setContentView(root);
        applyTarget(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        applyTarget(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        input.requestFocus();
        showLockoutIfAny();
    }

    private void applyTarget(Intent intent) {
        targetPkg = intent.getStringExtra(EXTRA_PKG);
        PackageManager pm = getPackageManager();
        try {
            ApplicationInfo ai = pm.getApplicationInfo(targetPkg, 0);
            title.setText(pm.getApplicationLabel(ai) + " terkunci");
            icon.setImageDrawable(pm.getApplicationIcon(ai));
        } catch (Exception e) {
            title.setText("Aplikasi terkunci");
            icon.setImageResource(R.drawable.ic_kunci);
        }
        input.setText("");
    }

    private void tryUnlock() {
        String pin = input.getText().toString();
        if (pin.isEmpty()) return;
        int result = Prefs.verify(this, pin);
        input.setText("");
        if (result == Prefs.OK) {
            AppLockService.unlockedPkg = targetPkg;
            finish();
            overridePendingTransition(0, 0);
        } else if (result == Prefs.LOCKED_OUT) {
            showLockoutIfAny();
        } else {
            message.setTextColor(Color.parseColor("#F97066"));
            message.setText("PIN salah, coba lagi");
        }
    }

    private void showLockoutIfAny() {
        long secs = Prefs.lockoutSecondsLeft(this);
        if (secs > 0) {
            message.setTextColor(Color.parseColor("#F97066"));
            message.setText("Terlalu banyak salah. Tunggu " + secs + " detik");
            input.setEnabled(false);
            handler.postDelayed(this::showLockoutIfAny, 1000);
        } else {
            input.setEnabled(true);
            if (message.getText().toString().startsWith("Terlalu")) {
                message.setTextColor(Color.parseColor("#98A2B3"));
                message.setText("Masukkan PIN untuk membuka");
            }
        }
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finish();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        goHome();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
